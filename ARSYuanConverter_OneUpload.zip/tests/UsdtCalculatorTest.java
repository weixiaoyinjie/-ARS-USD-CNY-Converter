import com.exchange.arsusdcny.UsdtCalculator;
import com.exchange.arsusdcny.FxCalculator;
import com.exchange.arsusdcny.FxCalculator.Currency;
import java.math.BigDecimal;

public class UsdtCalculatorTest {
    static BigDecimal n(String n) { return new BigDecimal(n); }
    static void eq(String expected, BigDecimal actual) {
        if (n(expected).compareTo(actual) != 0) throw new AssertionError(expected + " != " + actual);
    }
    public static void main(String[] args) {
        UsdtCalculator.Pair ars = new UsdtCalculator.Pair(n("1500"), n("1470"), "Binance P2P", 1700000000000L);
        UsdtCalculator.Pair cny = new UsdtCalculator.Pair(n("7.35"), n("7.20"), "Binance P2P", 1700000000000L);
        UsdtCalculator.Pair usd = new UsdtCalculator.Pair(n("1.005"), n("0.995"), "Binance USDC/USDT", 1700000000000L);
        eq("2", UsdtCalculator.convert(n("3000"), Currency.ARS, Currency.USDT, ars));
        eq("2940", UsdtCalculator.convert(n("2"), Currency.USDT, Currency.ARS, ars));
        eq("14.40", UsdtCalculator.convert(n("2"), Currency.USDT, Currency.CNY, cny));
        eq("2", UsdtCalculator.convert(n("14.70"), Currency.CNY, Currency.USDT, cny));
        eq("1.99", UsdtCalculator.convert(n("2"), Currency.USDT, Currency.USD, usd));
        eq("2", UsdtCalculator.convert(n("2.010"), Currency.USD, Currency.USDT, usd));
        eq("123", FxCalculator.parseAmount("123 USDT"));
        try {
            FxCalculator.convert(n("1"), Currency.USDT, Currency.ARS, n("1500"), n("1600"), n("7"));
            throw new AssertionError("Legacy quote cannot price USDT");
        } catch (IllegalArgumentException expected) { }
        System.out.println("All USDT quote/parse tests passed.");
    }
}
