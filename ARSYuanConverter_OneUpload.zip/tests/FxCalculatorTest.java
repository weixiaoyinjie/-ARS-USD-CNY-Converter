import com.exchange.arsusdcny.FxCalculator;
import com.exchange.arsusdcny.FxCalculator.Currency;
import java.math.BigDecimal;

public class FxCalculatorTest {
    static BigDecimal n(String x) { return new BigDecimal(x); }
    static void eq(String expected, BigDecimal got) {
        if (n(expected).compareTo(got) != 0) throw new AssertionError(expected + " != " + got);
    }
    public static void main(String[] args) {
        // 1 USD costs ARS 1,600 to buy, but sells for ARS 1,500.
        BigDecimal buy = n("1500"), sell = n("1600"), yuan = n("7");
        eq("100", FxCalculator.convert(n("160000"), Currency.ARS, Currency.USD, buy, sell, yuan));
        eq("700", FxCalculator.convert(n("160000"), Currency.ARS, Currency.CNY, buy, sell, yuan));
        eq("150000", FxCalculator.convert(n("100"), Currency.USD, Currency.ARS, buy, sell, yuan));
        eq("140", FxCalculator.convert(n("20"), Currency.USD, Currency.CNY, buy, sell, yuan));
        eq("150000", FxCalculator.convert(n("700"), Currency.CNY, Currency.ARS, buy, sell, yuan));
        eq("100", FxCalculator.convert(n("700"), Currency.CNY, Currency.USD, buy, sell, yuan));
        eq("1000000", FxCalculator.parseAmount("1,000,000"));
        eq("1000000", FxCalculator.parseAmount("1.000.000"));
        eq("1000000.50", FxCalculator.parseAmount("1.000.000,50"));
        eq("1000000.50", FxCalculator.parseAmount("1,000,000.50"));
        eq("6.68", FxCalculator.parseAmount("6,68"));
        eq("0.123", FxCalculator.parseAmount("0.123"));
        try {
            FxCalculator.parseAmount("-123");
            throw new AssertionError("Should reject negative amounts");
        } catch (NumberFormatException expected) { }
        System.out.println("All FX conversion/parse tests passed.");
    }
}
