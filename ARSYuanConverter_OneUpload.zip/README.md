# 阿根廷汇率通 · ARS/USD/CNY Android App

A minimal, Chinese-language native Android currency conversion app, written in Java with **no third-party Android dependencies**. It queries public USD/ARS market quotes via [DolarAPI](https://dolarapi.com) and USD/CNY reference exchange rates via [ExchangeRate-API](https://www.exchangerate-api.com).

## Features

- Seven Argentina USD markets: Blue, Oficial, MEP/Bolsa, CCL, Cripto, Mayorista, Tarjeta.
- Enter amount in ARS, USD, or CNY; see the other two conversions instantaneously.
- Explicit dealer-side buy/sell logic. ARS→USD divides by **venta**; USD→ARS multiplies by **compra**. CNY conversions use the USD→CNY indicative mid-market reference.
- Timestamp displays in Argentine local time. Refresh, on-device cached quotes, partial network failure behavior and stale-data warning.
- No user-provided API key, login, ads, location, or tracking dependencies.
- Long press/copy is not necessary: tap a result amount to copy it.
- Minimum Android 8.0 (API 26), target Android 14 (API 34).

## APIs

- `GET https://dolarapi.com/v1/dolares`
  - array of `{ casa, nombre, compra, venta, fechaActualizacion }`.
- `GET https://open.er-api.com/v6/latest/USD`
  - `{ result, base_code, time_last_update_unix, rates: { CNY } }`.

Attribution for ExchangeRate-API is visible and clickable in the app as required by its Open Access API terms. DolarAPI is also explicitly credited.

Automatic requests use 3-hour (DolarAPI) and 20-hour (USD/CNY) cache freshness thresholds. Manual refresh forces DolarAPI retrieval (subject to a 60-second anti-spam throttle); the USD/CNY source is updated at most every 20 hours to limit rate-limit issues.

## Exact conversion rules

| Direction | Formula |
|---|---|
| ARS → USD | `ARS / dolar.venta` |
| USD → ARS | `USD * dolar.compra` |
| USD → CNY | `USD * usdCnyRate` |
| CNY → USD | `CNY / usdCnyRate` |
| ARS → CNY | `(ARS / dolar.venta) * usdCnyRate` |
| CNY → ARS | `(CNY / usdCnyRate) * dolar.compra` |

**Note:** USD/CNY here is a reference exchange rate rather than a retail cash rate. The ARS/CNY cross-rate does not include fees, transfer costs, or CNY bid-ask spreads. Tarjeta is a consumer-card rate, not a general cash buy/sell offer; Blue is unofficial.

## Build on GitHub Actions (simplest for mobile)

1. Create a **new, empty** repository at `https://github.com/new`, with the default branch `main`.
2. Upload `ARSYuanConverter_OneUpload.zip` at the **repository root**. Upload the `.zip` file itself (do not unzip it inside GitHub).
3. Create `.github/workflows/build-apk.yml` and paste the standalone `build-apk.yml` file content provided alongside the ZIP. Important: `.github/workflows/` is the path, not the repository root.
4. Open **Actions → Build ARS USD CNY APK → Run workflow** (or wait for the push trigger), then open the latest successful run.
5. Download the **ARS-USD-CNY-Rates-APK** artifact ZIP and extract `ARS_USD_CNY_Rates_v1.0-debug.apk`, then install on Android. You may need to enable installing apps from that source.

## Build with Android Studio

Extract `ARSYuanConverter_OneUpload.zip` to a folder, and open the folder containing `settings.gradle` in a recent Android Studio. Use the **Build → Build APK(s)** command. Android Gradle plugin 8.7.3, Gradle 8.10.2, Java 17, compile SDK 35.

## Unit tests

The pure-Java math module can be tested locally without Android SDK:

```bash
javac -d /tmp/fx-tests app/src/main/java/com/exchange/arsusdcny/FxCalculator.java tests/FxCalculatorTest.java
java -cp /tmp/fx-tests FxCalculatorTest
```

## Important limitation

Live exchange rates require network access. When providers are unavailable, saved rates remain visible with their source timestamps; the app does not fabricate current prices. This repository contains a buildable Android project and a cloud build workflow; it does not imply that any APK has been locally compiled or installed.
