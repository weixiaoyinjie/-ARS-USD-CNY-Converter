# 阿根廷汇率通 v1.1 · ARS / USD / CNY / USDT

基于原版 `ARSYuanConverter_OneUpload.zip` 做的最小改动版本。**保留旧版所有 7 种美元市场、历史汇率展示、ARS/USD/CNY 六种换算方向、点击复制、缓存、手动刷新和中文界面**，仅扩展 USDT：

- 输入货币增加 `USDT` 第四个选项，原金额输入框继续使用。
- 选择 ARS / USD / CNY 时，原来两个换算结果顺序不变，末尾增加 USDT 换算结果。
- 选择 USDT 时，依次显示 ARS、USD 和 CNY，三个结果均可点击复制。
- 新增单独的 Binance USDT 汇率区，显示 USDT→ARS/USD/CNY 卖价、买价、报价来源、阿根廷时区时间。
- 不索取 Binance API Key，无需登录，无新隐私权限。

## 汇率：不同报价，绝不混用

原版数据源和公式都保留：

- `https://dolarapi.com/v1/dolares`：阿根廷传统美元市场，报价分 `compra`/`venta`。
- `https://open.er-api.com/v6/latest/USD`：USD/CNY 参考汇率（非现金买卖价）。
- 原版 ARS↔USD↔CNY 换算仍按照原逻辑进行，与 USDT 报价完全分离。

**USDT 新报价仅来自 Binance，或经过清晰标注的交叉参考价**：

1. **USDT/ARS 和 USDT/CNY 优先走 Binance P2P 公开 GET 报价**，分别获取买入 `BUY` 和卖出 `SELL`：
   `https://www.binance.com/bapi/c2c/v1/public/c2c/agent/quote-price?fiat=ARS&asset=USDT&tradeType=BUY`
   将 `ARS` 替换为 `CNY`，`BUY` 替换为 `SELL` 即可获取对应方向。使用的是币安提供的无密钥查询接口；因地区限制、反机器人策略或接口变更可能无法获取。
2. **USDT/USD 近似**：币安现货 `GET https://data-api.binance.vision/api/v3/ticker/bookTicker?symbol=USDCUSDT`，将 USDC 当成美元*价格参考代理*，按买一卖一计算。**USDC 不是法定美元**，其交易价可能偏离 1 USD。
3. **USDT/ARS 备用参考**：当 P2P 不可用时，如币安 USDC/ARS 现货交易对可用，使用上述 USDC/USDT 和币安 `USDCARS` 的买卖盘口交叉计算；来源显示“现货交叉参考”，不会冒充 P2P 成交报价。
4. **USDT/CNY 备用参考**：当 P2P 不可用时，使用币安 USDC/USDT 与原版 USD/CNY 参考报价交叉计算；来源显示“交叉参考”，不会冒充 Binance CNY P2P 实价。

**买卖价方向**：ARS/CNY/USD → USDT 按*用户买入 USDT 的报价*计算（付款法币 ÷ 买入价）；USDT → ARS/CNY/USD 按*用户卖出 USDT 的报价*计算（USDT × 卖出价）。不假设 USDT 与 USD 恒等，也不把 Blue/Cripto USD 汇率当 Binance USDT/ARS。

数据刷新时会缓存 Binance 报价，后续启动过 3 分钟即尝试重新获取，展示时间和过期警告。无有效最新价/缓存则清晰显示“汇率未加载”，**不会编造数字**。网络请求在后台线程，P2P 两种币的查询并行执行。手动刷新延用原 60 秒限频。网络环境没有经过实际 Android 真机联调，故 Binance API 可用性依设备网络及地区而定。

## GitHub 手机一键编译方式

**已有旧版仓库**：将本 ZIP **保持文件名 `ARSYuanConverter_OneUpload.zip`**，直接上传至旧 GitHub 仓库根目录并覆盖原 ZIP。旧版 Action 配置监听这个文件名，因此上传后能按原方法自动编译。若旧工作流已经存在，旧工作流的产物文件名可能仍显示 `v1.0`，但 APK 内应用版本号会是 `1.1.0`；可选择一并替换外层 `.github/workflows/build-apk.yml` 为本包同名文件，以更新显示名称和单元测试。

**新建仓库**：

1. 打开 `https://github.com/new` 建立空仓库。
2. 上传本 ZIP（**不要解压**）至根目录。
3. 将 ZIP 内的 `.github/workflows/build-apk.yml` 单独取出，上传为仓库中的 `.github/workflows/build-apk.yml`（GitHub 不会自动运行 ZIP 内的工作流文件）。
4. 进入 Actions → `Build ARS USD CNY USDT APK` → `Run workflow`，或在 push 后自动编译。
5. 下载 Actions Artifact `ARS-USD-CNY-USDT-Rates-APK`，解压后安装 `ARS_USD_CNY_USDT_Rates_v1.1-debug.apk`。

也可将本 ZIP 解压后使用 Android Studio 构建。Java 17、Android SDK 35、Gradle 8.10.2、Android Gradle 插件 8.7.3，最低 Android 8（API 26）。原 applicationId 保持 `com.exchange.arsusdcny`，Android 版本号 `1.1.0`，版本码 2。

## 数学单元测试

```bash
mkdir -p /tmp/fx-tests
javac -d /tmp/fx-tests \
  app/src/main/java/com/exchange/arsusdcny/FxCalculator.java \
  app/src/main/java/com/exchange/arsusdcny/UsdtCalculator.java \
  tests/FxCalculatorTest.java tests/UsdtCalculatorTest.java
java -cp /tmp/fx-tests FxCalculatorTest
java -cp /tmp/fx-tests UsdtCalculatorTest
```

测试验证原版 6 个方向与新增 USDT 买卖价换算，以及负数和混用报价处理。**交付的是可供云端编译的完整 Java/Android ZIP 源码，不是已在真机运行验证的 APK。**
