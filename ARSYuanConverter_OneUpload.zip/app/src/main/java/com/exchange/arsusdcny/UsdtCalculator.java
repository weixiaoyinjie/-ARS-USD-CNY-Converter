package com.exchange.arsusdcny;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import com.exchange.arsusdcny.FxCalculator.Currency;

/** Strict USDT fiat quotes, without assuming USDT = USD or using Blue USD as USDT/ARS. */
public final class UsdtCalculator {
    private UsdtCalculator() {}
    public static final MathContext MC = new MathContext(18, RoundingMode.HALF_UP);

    public static final class Pair {
        /** Fiat paid by customer to acquire 1 USDT (P2P BUY). */
        public final BigDecimal buyUsdt;
        /** Fiat received by customer upon selling 1 USDT (P2P SELL). */
        public final BigDecimal sellUsdt;
        public final String source;
        public final long fetchedAt;
        public Pair(BigDecimal buyUsdt, BigDecimal sellUsdt, String source, long fetchedAt) {
            if (buyUsdt == null || sellUsdt == null || buyUsdt.signum() <= 0 || sellUsdt.signum() <= 0)
                throw new IllegalArgumentException("Positive quotes required");
            if (source == null || source.isEmpty() || fetchedAt <= 0)
                throw new IllegalArgumentException("Quote provenance required");
            this.buyUsdt = buyUsdt;
            this.sellUsdt = sellUsdt;
            this.source = source;
            this.fetchedAt = fetchedAt;
        }
    }

    public static BigDecimal convert(BigDecimal amount, Currency from, Currency to, Pair quote) {
        if (amount == null || from == null || to == null || amount.signum() < 0)
            throw new IllegalArgumentException("Invalid amount/currencies");
        if (from == to) return amount;
        if (quote == null || (from != Currency.USDT && to != Currency.USDT))
            throw new IllegalArgumentException("A direct USDT pair quote is required");
        if (from == Currency.USDT) return amount.multiply(quote.sellUsdt, MC);
        return amount.divide(quote.buyUsdt, MC);
    }
}
