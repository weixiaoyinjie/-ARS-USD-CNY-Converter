package com.exchange.arsusdcny;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.exchange.arsusdcny.FxCalculator.Currency;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(7, 22, 35);
    private static final int CARD = Color.rgb(16, 40, 57);
    private static final int CARD_ALT = Color.rgb(19, 48, 65);
    private static final int BORDER = Color.rgb(42, 75, 91);
    private static final int TEXT = Color.rgb(243, 251, 252);
    private static final int MUTED = Color.rgb(151, 180, 193);
    private static final int ACCENT = Color.rgb(35, 212, 180);
    private static final int WARNING = Color.rgb(255, 202, 123);

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ExecutorService binanceExecutor = Executors.newFixedThreadPool(2);
    private final Map<String, RateService.Quote> quotes = new LinkedHashMap<>();
    private final Map<Currency, UsdtCalculator.Pair> usdtQuotes = new LinkedHashMap<>();
    private final Map<String, TextView> marketButtons = new LinkedHashMap<>();
    private final Map<Currency, TextView> currencyButtons = new LinkedHashMap<>();
    private SharedPreferences prefs;
    private Currency selectedCurrency = Currency.ARS;
    private String selectedMarket = "blue";
    private BigDecimal cnyPerUsd = null;
    private long fetchedDolarAt = 0, fetchedCnyAt = 0, cnySourceTime = 0;
    private boolean loading = false;
    private String latestError = "";

    private TextView stateLabel, buyLabel, sellLabel, cnyLabel, updateLabel, conversionHint;
    private TextView usdtArsLabel, usdtUsdLabel, usdtCnyLabel, usdtInfoLabel;
    private TextView resultOneLabel, resultOneValue, resultTwoLabel, resultTwoValue;
    private TextView resultThreeLabel, resultThreeValue, sourceName;
    private TextView refreshButton;
    private LinearLayout quoteList;
    private EditText amountInput;
    private final Map<Currency, String> resultValues = new LinkedHashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        prefs = getSharedPreferences("fx_rates_v1", MODE_PRIVATE);
        selectedMarket = prefs.getString("preferred_market", "blue");
        String currency = prefs.getString("preferred_currency", "ARS");
        try { selectedCurrency = Currency.valueOf(currency); }
        catch (Exception ignored) { selectedCurrency = Currency.ARS; }
        loadCachedRates();
        buildScreen();
        render();
        long now = System.currentTimeMillis();
        if (quotes.isEmpty() || cnyPerUsd == null || needsUsdtRefresh(now) ||
                now - fetchedDolarAt > 3L * 3600000 || now - fetchedCnyAt > 20L * 3600000) {
            refreshRates(false);
        }
    }

    private int dp(float num) { return Math.round(num * getResources().getDisplayMetrics().density); }
    private GradientDrawable rounded(int color, float radiusDp, int outline) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (outline != 0) d.setStroke(dp(1), outline);
        return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setIncludeFontPadding(true);
        return view;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width == -1 ? -1 : dp(width), height == -1 || height == -2 ? height : dp(height));
    }
    private void topGap(LinearLayout container, int height) {
        View gap = new View(this);
        container.addView(gap, lp(1, height));
    }
    private LinearLayout card(LinearLayout parent) {
        LinearLayout box = vertical();
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(rounded(CARD, 18, BORDER));
        parent.addView(box, lp(-1, -2));
        return box;
    }
    private void section(LinearLayout parent, String heading) {
        topGap(parent, 22);
        TextView h = text(heading, 16, TEXT, true);
        parent.addView(h);
        topGap(parent, 10);
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);
        LinearLayout root = vertical();
        root.setPadding(dp(18), dp(24), dp(18), dp(35));
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout header = horizontal();
        root.addView(header, lp(-1, -2));
        LinearLayout titleBox = vertical();
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        titleBox.addView(text("阿根廷汇率通", 27, TEXT, true));
        titleBox.addView(text("ARS · USD · CNY · USDT  实时查询与换算", 12, MUTED, false));
        refreshButton = text("↻  刷新", 14, BG, true);
        refreshButton.setGravity(Gravity.CENTER);
        refreshButton.setPadding(dp(13), dp(10), dp(13), dp(10));
        refreshButton.setBackground(rounded(ACCENT, 14, 0));
        header.addView(refreshButton);
        refreshButton.setOnClickListener(v -> refreshRates(true));
        topGap(root, 18);

        LinearLayout statusCard = card(root);
        stateLabel = text("正在检查汇率…", 13, ACCENT, true);
        statusCard.addView(stateLabel);
        topGap(statusCard, 5);
        updateLabel = text("", 11, MUTED, false);
        statusCard.addView(updateLabel);

        section(root, "选择阿根廷美元市场");
        HorizontalScrollView marketsScroll = new HorizontalScrollView(this);
        marketsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = horizontal();
        chips.setPadding(0, dp(2), dp(2), dp(2));
        marketsScroll.addView(chips);
        for (String[] market : RateService.MARKETS) {
            final String id = market[0];
            TextView chip = text(market[1], 13, TEXT, true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(17), dp(11), dp(17), dp(11));
            LinearLayout.LayoutParams param = lp(-2, -2);
            param.rightMargin = dp(8);
            chips.addView(chip, param);
            marketButtons.put(id, chip);
            chip.setOnClickListener(v -> {
                selectedMarket = id;
                prefs.edit().putString("preferred_market", id).apply();
                render();
            });
        }
        root.addView(marketsScroll, lp(-1, -2));

        section(root, "金额换算");
        LinearLayout conversionCard = card(root);
        conversionCard.addView(text("选择输入货币", 12, MUTED, false));
        topGap(conversionCard, 11);
        LinearLayout fromRow = horizontal();
        conversionCard.addView(fromRow, lp(-1, -2));
        for (Currency cur : Currency.values()) {
            String display = cur == Currency.ARS ? "ARS 比索" : cur == Currency.USD ? "USD 美元" :
                    cur == Currency.CNY ? "CNY 人民币" : "USDT";
            TextView chip = text(display, 11, TEXT, true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(4), dp(12), dp(4), dp(12));
            LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(0, -2, 1);
            param.rightMargin = dp(cur == Currency.USDT ? 0 : 5);
            fromRow.addView(chip, param);
            currencyButtons.put(cur, chip);
            chip.setOnClickListener(v -> {
                selectedCurrency = cur;
                prefs.edit().putString("preferred_currency", cur.name()).apply();
                render();
            });
        }
        topGap(conversionCard, 16);
        sourceName = text("输入金额", 12, MUTED, false);
        conversionCard.addView(sourceName);
        topGap(conversionCard, 7);
        amountInput = new EditText(this);
        amountInput.setSingleLine(true);
        amountInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        amountInput.setTextColor(TEXT);
        amountInput.setHintTextColor(MUTED);
        amountInput.setHint("例如：1000000");
        amountInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER |
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        amountInput.setPadding(dp(15), dp(12), dp(15), dp(12));
        amountInput.setBackground(rounded(BG, 13, BORDER));
        conversionCard.addView(amountInput, lp(-1, -2));
        amountInput.setText("1000000");
        amountInput.setSelection(amountInput.length());
        amountInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateCalculations(); }
            @Override public void afterTextChanged(Editable e) {}
        });
        topGap(conversionCard, 16);
        conversionHint = text("", 12, MUTED, false);
        conversionCard.addView(conversionHint);
        topGap(conversionCard, 16);
        LinearLayout resultA = resultCard(conversionCard, true);
        resultOneLabel = (TextView) resultA.getChildAt(0);
        resultOneValue = (TextView) resultA.getChildAt(1);
        topGap(conversionCard, 9);
        LinearLayout resultB = resultCard(conversionCard, false);
        resultTwoLabel = (TextView) resultB.getChildAt(0);
        resultTwoValue = (TextView) resultB.getChildAt(1);
        topGap(conversionCard, 9);
        LinearLayout resultC = resultCard(conversionCard, false);
        resultThreeLabel = (TextView) resultC.getChildAt(0);
        resultThreeValue = (TextView) resultC.getChildAt(1);
        resultOneValue.setOnClickListener(v -> copyResult(resultOneLabel.getText().toString()));
        resultTwoValue.setOnClickListener(v -> copyResult(resultTwoLabel.getText().toString()));
        resultThreeValue.setOnClickListener(v -> copyResult(resultThreeLabel.getText().toString()));
        topGap(conversionCard, 13);
        conversionCard.addView(text("轻触换算金额可复制 · 结果为参考估算，不含手续费与实际成交差价。", 11, MUTED, false));

        section(root, "所选市场报价");
        LinearLayout quoteCard = card(root);
        TextView title = text("每 1 USD 对应的阿根廷比索", 12, MUTED, false);
        quoteCard.addView(title);
        topGap(quoteCard, 10);
        LinearLayout quotesRow = horizontal();
        quoteCard.addView(quotesRow, lp(-1, -2));
        LinearLayout left = vertical(), right = vertical();
        quotesRow.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        quotesRow.addView(right, new LinearLayout.LayoutParams(0, -2, 1));
        left.addView(text("Compra 买入美元", 12, MUTED, false));
        buyLabel = text("—", 23, TEXT, true);
        left.addView(buyLabel);
        right.addView(text("Venta 卖出美元", 12, MUTED, false));
        sellLabel = text("—", 23, ACCENT, true);
        right.addView(sellLabel);
        topGap(quoteCard, 12);
        quoteCard.addView(text("这里的 Compra / Venta 是报价方买入或卖出美元，而非用户买卖比索的方向。", 11, MUTED, false));

        section(root, "美元 / 人民币参考汇率");
        LinearLayout yuanCard = card(root);
        cnyLabel = text("1 USD = — CNY", 21, TEXT, true);
        yuanCard.addView(cnyLabel);
        topGap(yuanCard, 5);
        yuanCard.addView(text("采用美元对人民币参考中间汇率；人民币与比索通过美元交叉计算。", 12, MUTED, false));

        section(root, "Binance USDT 汇率");
        LinearLayout usdtCard = card(root);
        usdtArsLabel = text("1 USDT = — ARS", 17, TEXT, true);
        usdtCard.addView(usdtArsLabel);
        topGap(usdtCard, 8);
        usdtUsdLabel = text("1 USDT ≈ — USD", 17, TEXT, true);
        usdtCard.addView(usdtUsdLabel);
        topGap(usdtCard, 8);
        usdtCnyLabel = text("1 USDT = — CNY", 17, TEXT, true);
        usdtCard.addView(usdtCnyLabel);
        topGap(usdtCard, 9);
        usdtInfoLabel = text("USDT 买卖价可能不同；数据加载中…", 11, MUTED, false);
        usdtCard.addView(usdtInfoLabel);

        section(root, "全部美元报价（ARS / USD）");
        LinearLayout tableCard = card(root);
        LinearLayout headers = horizontal();
        tableCard.addView(headers, lp(-1, -2));
        TextView h1 = text("市场", 12, MUTED, true);
        TextView h2 = text("Compra", 12, MUTED, true);
        TextView h3 = text("Venta", 12, MUTED, true);
        headers.addView(h1, new LinearLayout.LayoutParams(0, -2, 1.15f));
        h2.setGravity(Gravity.RIGHT);
        h3.setGravity(Gravity.RIGHT);
        headers.addView(h2, new LinearLayout.LayoutParams(0, -2, 1));
        headers.addView(h3, new LinearLayout.LayoutParams(0, -2, 1));
        topGap(tableCard, 7);
        quoteList = vertical();
        tableCard.addView(quoteList);

        section(root, "数据来源和说明");
        LinearLayout sourcesCard = card(root);
        addLink(sourcesCard, "DolarAPI — 阿根廷美元多市场报价", "https://dolarapi.com");
        topGap(sourcesCard, 9);
        addLink(sourcesCard, "Rates By Exchange Rate API — USD/CNY", "https://www.exchangerate-api.com");
        topGap(sourcesCard, 9);
        addLink(sourcesCard, "Binance — USDT P2P 与公开现货行情", "https://www.binance.com");
        topGap(sourcesCard, 13);
        sourcesCard.addView(text("美元报价的 Compra / Venta 可能来自不同市场，包含流动性、税费或交易限制。Blue 属非官方市场；Tarjeta 通常不能直接视为现金兑换报价。跨币种金额仅供核算参考。", 12, MUTED, false));
        topGap(sourcesCard, 10);
        sourcesCard.addView(text("数据加载失败时可查看本机缓存；请注意报价更新时间。应用不请求账户、定位或其他个人资料。", 11, MUTED, false));
    }

    private LinearLayout resultCard(LinearLayout parent, boolean highlight) {
        LinearLayout result = vertical();
        result.setPadding(dp(14), dp(13), dp(14), dp(13));
        result.setBackground(rounded(highlight ? CARD_ALT : BG, 13, BORDER));
        parent.addView(result, lp(-1, -2));
        result.addView(text("换算结果", 12, MUTED, false));
        result.addView(text("—", 26, highlight ? ACCENT : TEXT, true));
        return result;
    }
    private void addLink(LinearLayout parent, String label, String url) {
        TextView link = text("↗  " + label, 12, ACCENT, false);
        parent.addView(link);
        link.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            catch (Exception ex) { Toast.makeText(this, "无法打开链接", Toast.LENGTH_SHORT).show(); }
        });
    }
    private void refreshSelectionUi() {
        for (Map.Entry<String, TextView> entry : marketButtons.entrySet()) {
            boolean selected = entry.getKey().equals(selectedMarket);
            TextView chip = entry.getValue();
            chip.setBackground(rounded(selected ? ACCENT : CARD, 14, selected ? 0 : BORDER));
            chip.setTextColor(selected ? BG : TEXT);
        }
        for (Map.Entry<Currency, TextView> entry : currencyButtons.entrySet()) {
            boolean selected = entry.getKey() == selectedCurrency;
            TextView chip = entry.getValue();
            chip.setBackground(rounded(selected ? ACCENT : CARD_ALT, 10, selected ? 0 : BORDER));
            chip.setTextColor(selected ? BG : TEXT);
        }
    }
    private RateService.Quote chosenQuote() { return quotes.get(selectedMarket); }
    private void render() {
        refreshSelectionUi();
        RateService.Quote quote = chosenQuote();
        if (quote != null) {
            buyLabel.setText(format(quote.compra, 2));
            sellLabel.setText(format(quote.venta, 2));
        } else {
            buyLabel.setText("—");
            sellLabel.setText("—");
        }
        if (cnyPerUsd != null) cnyLabel.setText("1 USD = " + format(cnyPerUsd, 4) + " CNY");
        else cnyLabel.setText("1 USD = — CNY");
        updateUsdtSection();
        if (loading) {
            stateLabel.setText("● 正在更新数据…");
            stateLabel.setTextColor(WARNING);
            refreshButton.setAlpha(0.6f);
        } else {
            refreshButton.setAlpha(1.0f);
            if (quote == null && cnyPerUsd == null && usdtQuotes.isEmpty()) {
                stateLabel.setText("● 暂无汇率数据，请连接网络刷新");
                stateLabel.setTextColor(WARNING);
            } else if (!latestError.isEmpty()) {
                stateLabel.setText("● 部分更新失败 · 显示可用数据/缓存");
                stateLabel.setTextColor(WARNING);
            } else if (quote == null || cnyPerUsd == null || usdtQuotes.size() < 3) {
                stateLabel.setText("● 只有部分货币汇率可用");
                stateLabel.setTextColor(WARNING);
            } else {
                stateLabel.setText("● 汇率数据已就绪");
                stateLabel.setTextColor(ACCENT);
            }
        }
        String usdTime = quote == null ? "无数据" : argentinaDate(parseInstant(quote.updated));
        String cnyTime = cnyPerUsd == null ? "无数据" : argentinaDate(cnySourceTime);
        String warning = "";
        long now = System.currentTimeMillis();
        if (fetchedDolarAt > 0 && now - fetchedDolarAt > 6L * 3600000) warning += " · 美元缓存较旧";
        if (fetchedCnyAt > 0 && now - fetchedCnyAt > 36L * 3600000) warning += " · 人民币缓存较旧";
        for (UsdtCalculator.Pair p : usdtQuotes.values()) {
            if (now - p.fetchedAt > 15L * 60000) { warning += " · USDT 报价已超过15分钟"; break; }
        }
        updateLabel.setText("阿根廷美元更新：" + usdTime + "  ·  USD/CNY 更新：" + cnyTime + "\n均以阿根廷时间显示" + warning +
                (latestError.isEmpty() ? "" : "\n" + latestError));
        sourceName.setText("输入 " + (selectedCurrency == Currency.ARS ? "阿根廷比索 ARS" :
                selectedCurrency == Currency.USD ? "美元 USD" :
                selectedCurrency == Currency.CNY ? "人民币 CNY" : "USDT 泰达币") + " 金额");
        updateQuoteList();
        updateCalculations();
    }
    private void updateQuoteList() {
        quoteList.removeAllViews();
        for (String[] entry : RateService.MARKETS) {
            RateService.Quote q = quotes.get(entry[0]);
            LinearLayout row = horizontal();
            row.setPadding(dp(0), dp(12), dp(0), dp(12));
            if (entry[0].equals(selectedMarket)) row.setBackground(rounded(CARD_ALT, 8, 0));
            TextView name = text(entry[1], 12, entry[0].equals(selectedMarket) ? ACCENT : TEXT, true);
            TextView buy = text(q == null ? "—" : format(q.compra, 2), 12, TEXT, false);
            TextView sell = text(q == null ? "—" : format(q.venta, 2), 12, TEXT, false);
            buy.setGravity(Gravity.RIGHT);
            sell.setGravity(Gravity.RIGHT);
            row.addView(name, new LinearLayout.LayoutParams(0, -2, 1.15f));
            row.addView(buy, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(sell, new LinearLayout.LayoutParams(0, -2, 1));
            quoteList.addView(row, lp(-1, -2));
            row.setOnClickListener(v -> {
                selectedMarket = entry[0];
                prefs.edit().putString("preferred_market", selectedMarket).apply();
                render();
            });
            View line = new View(this);
            line.setBackgroundColor(BORDER);
            quoteList.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        }
    }
    private void updateUsdtSection() {
        usdtArsLabel.setText(formatUsdtLine(Currency.ARS));
        usdtUsdLabel.setText(formatUsdtLine(Currency.USD));
        usdtCnyLabel.setText(formatUsdtLine(Currency.CNY));
        StringBuilder info = new StringBuilder("买入 USDT 使用买价；卖出 USDT 使用卖价。\n");
        for (Currency fiat : new Currency[]{Currency.ARS, Currency.USD, Currency.CNY}) {
            UsdtCalculator.Pair q = usdtQuotes.get(fiat);
            if (q != null) info.append(fiat.name()).append("：").append(q.source)
                    .append(" · ").append(argentinaDate(q.fetchedAt)).append("\n");
            else info.append(fiat.name()).append("：Binance 报价暂不可用\n");
        }
        info.append("USD 以 USDC/USDT 现货近似；交叉价不等于 P2P 可成交价，不含手续费。");
        usdtInfoLabel.setText(info.toString());
    }
    private String formatUsdtLine(Currency fiat) {
        UsdtCalculator.Pair p = usdtQuotes.get(fiat);
        if (p == null) return "1 USDT = — " + fiat.name();
        return "1 USDT → " + format(p.sellUsdt, fiat == Currency.ARS ? 2 : 4) + " " + fiat.name()
                + "  · 买入价 " + format(p.buyUsdt, fiat == Currency.ARS ? 2 : 4);
    }
    private void updateCalculations() {
        resultValues.clear();
        Currency first = selectedCurrency == Currency.ARS ? Currency.USD : Currency.ARS;
        Currency second = selectedCurrency == Currency.CNY ? Currency.USD : Currency.CNY;
        if (selectedCurrency == Currency.USDT) { first = Currency.ARS; second = Currency.USD; }
        Currency third = selectedCurrency == Currency.USDT ? Currency.CNY : Currency.USDT;
        resultOneLabel.setText(label(first));
        resultTwoLabel.setText(label(second));
        resultThreeLabel.setText(label(third));
        conversionHint.setText(selectedCurrency == Currency.USDT ?
                "USDT 换法币使用 Binance 卖出参考价；法币换 USDT 使用买入参考价。" :
                selectedCurrency == Currency.ARS ?
                "比索买美元使用 Venta；USDT 使用单独的 Binance 买卖价。" :
                "原美元/比索/人民币换算规则不变；USDT 单独按 Binance 报价换算。");
        String raw = amountInput.getText().toString();
        BigDecimal amount;
        try { amount = FxCalculator.parseAmount(raw); }
        catch (Exception ex) {
            resultOneValue.setText(raw.trim().isEmpty() ? "输入金额后计算" : "金额格式不正确");
            resultTwoValue.setText("—");
            resultThreeValue.setText("—");
            return;
        }
        renderResult(first, amount, resultOneValue);
        renderResult(second, amount, resultTwoValue);
        renderResult(third, amount, resultThreeValue);
    }
    private void renderResult(Currency to, BigDecimal amount, TextView target) {
        if (selectedCurrency == Currency.USDT || to == Currency.USDT) {
            Currency fiat = selectedCurrency == Currency.USDT ? to : selectedCurrency;
            UsdtCalculator.Pair pair = usdtQuotes.get(fiat);
            if (pair == null) {
                target.setText("Binance " + fiat.name() + "/USDT 汇率未加载");
                return;
            }
            try {
                BigDecimal result = UsdtCalculator.convert(amount, selectedCurrency, to, pair);
                String formatted = format(result, 2);
                target.setText(formatted + " " + to.name() + "   ⧉");
                resultValues.put(to, formatted + " " + to.name());
            } catch (Exception ex) { target.setText("无法换算"); }
            return;
        }
        RateService.Quote quote = chosenQuote();
        if (quote == null && (to == Currency.ARS || selectedCurrency == Currency.ARS)) {
            target.setText("缺少该市场汇率");
            return;
        }
        if (cnyPerUsd == null && (to == Currency.CNY || selectedCurrency == Currency.CNY)) {
            target.setText("人民币汇率未加载");
            return;
        }
        BigDecimal compra = quote == null ? BigDecimal.ONE : quote.compra;
        BigDecimal venta = quote == null ? BigDecimal.ONE : quote.venta;
        BigDecimal yuan = cnyPerUsd == null ? BigDecimal.ONE : cnyPerUsd;
        try {
            BigDecimal result = FxCalculator.convert(amount, selectedCurrency, to, compra, venta, yuan);
            String formatted = format(result, 2);
            target.setText(formatted + " " + to.name() + "   ⧉");
            resultValues.put(to, formatted + " " + to.name());
        } catch (Exception ex) { target.setText("无法换算"); }
    }
    private String label(Currency cur) {
        return cur == Currency.ARS ? "阿根廷比索 ARS" : cur == Currency.USD ? "美元 USD" :
                cur == Currency.CNY ? "人民币 CNY" : "泰达币 USDT";
    }
    private void copyResult(String label) {
        Currency target = label.contains("USDT") ? Currency.USDT : label.contains("ARS") ? Currency.ARS :
                label.contains("USD") ? Currency.USD : Currency.CNY;
        String copied = resultValues.get(target);
        if (copied == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("换算金额", copied));
        Toast.makeText(this, "已复制 " + copied, Toast.LENGTH_SHORT).show();
    }
    private String format(BigDecimal n, int scale) {
        NumberFormat formatter = NumberFormat.getNumberInstance(Locale.US);
        formatter.setGroupingUsed(true);
        formatter.setRoundingMode(RoundingMode.HALF_UP);
        formatter.setMinimumFractionDigits(scale);
        formatter.setMaximumFractionDigits(scale);
        return formatter.format(n);
    }
    private long parseInstant(String value) {
        try { return Instant.parse(value).toEpochMilli(); }
        catch (Exception e) { return 0; }
    }
    private String argentinaDate(long timestamp) {
        if (timestamp <= 0) return "未知";
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("America/Argentina/Buenos_Aires"));
        return f.format(new Date(timestamp));
    }
    private void loadCachedRates() {
        try {
            String raw = prefs.getString("cached_dolar", "");
            if (!raw.isEmpty()) quotes.putAll(RateService.parseDollars(raw));
            fetchedDolarAt = prefs.getLong("cached_dolar_at", 0);
        } catch (Exception ignored) { quotes.clear(); }
        try {
            String raw = prefs.getString("cached_cny", "");
            if (!raw.isEmpty()) {
                RateService.YuanRate rate = RateService.parseCny(raw);
                cnyPerUsd = rate.cnyPerUsd;
                cnySourceTime = rate.sourceTimestampMs;
            }
            fetchedCnyAt = prefs.getLong("cached_cny_at", 0);
        } catch (Exception ignored) { cnyPerUsd = null; }
        for (Currency cur : new Currency[]{Currency.ARS, Currency.USD, Currency.CNY}) {
            try {
                String raw = prefs.getString("cached_usdt_" + cur.name(), "");
                if (!raw.isEmpty()) usdtQuotes.put(cur, BinanceRateService.pairFromCache(raw));
            } catch (Exception ignored) { usdtQuotes.remove(cur); }
        }
    }
    private boolean needsUsdtRefresh(long now) {
        for (Currency cur : new Currency[]{Currency.ARS, Currency.USD, Currency.CNY}) {
            UsdtCalculator.Pair q = usdtQuotes.get(cur);
            if (q == null || now - q.fetchedAt > 3L * 60000) return true;
        }
        return false;
    }
    private void refreshRates(boolean manual) {
        if (loading) return;
        long now = System.currentTimeMillis();
        if (manual && now - prefs.getLong("last_manual_refresh", 0) < 60000) {
            Toast.makeText(this, "请至少间隔一分钟再刷新", Toast.LENGTH_SHORT).show();
            return;
        }
        if (manual) prefs.edit().putLong("last_manual_refresh", now).apply();
        loading = true;
        latestError = "";
        render();
        final boolean needDolar = manual || quotes.isEmpty() || now - fetchedDolarAt >= 3L * 3600000;
        final boolean needCny = cnyPerUsd == null || now - fetchedCnyAt >= 20L * 3600000;
        final boolean needBinance = manual || needsUsdtRefresh(now);
        executor.execute(() -> {
            String dollarRaw = null;
            String cnyRaw = null;
            Map<String, RateService.Quote> newQuotes = null;
            RateService.YuanRate newYuan = null;
            StringBuilder errors = new StringBuilder();
            if (needDolar) {
                try {
                    dollarRaw = RateService.fetch(RateService.DOLAR_ENDPOINT);
                    newQuotes = RateService.parseDollars(dollarRaw);
                } catch (Exception e) { errors.append("DolarAPI 连接失败（").append(e.getMessage()).append("）"); }
            }
            if (needCny) {
                try {
                    cnyRaw = RateService.fetch(RateService.CNY_ENDPOINT);
                    newYuan = RateService.parseCny(cnyRaw);
                } catch (Exception e) {
                    if (errors.length() > 0) errors.append("；");
                    errors.append("USD/CNY 连接失败（").append(e.getMessage()).append("）");
                }
            }
            Map<Currency, UsdtCalculator.Pair> newUsdt = new LinkedHashMap<>();
            if (needBinance) {
                long at = System.currentTimeMillis();
                BinanceRateService.Book usdcBook = null;
                try {
                    usdcBook = BinanceRateService.parseSpotBook(
                            RateService.fetch(BinanceRateService.SPOT_BASE + "USDCUSDT"), "USDCUSDT");
                    newUsdt.put(Currency.USD, BinanceRateService.usdFromUsdcBook(usdcBook, at));
                } catch (Exception ignored) { /* USD not fabricated without Binance data */ }
                Future<UsdtCalculator.Pair> arsFuture = binanceExecutor.submit(
                        () -> BinanceRateService.fetchP2pPair("ARS", at));
                Future<UsdtCalculator.Pair> cnyFuture = binanceExecutor.submit(
                        () -> BinanceRateService.fetchP2pPair("CNY", at));
                try { newUsdt.put(Currency.ARS, arsFuture.get(25, TimeUnit.SECONDS)); }
                catch (Exception ignored) { arsFuture.cancel(true); }
                try { newUsdt.put(Currency.CNY, cnyFuture.get(25, TimeUnit.SECONDS)); }
                catch (Exception ignored) { cnyFuture.cancel(true); }
                if (!newUsdt.containsKey(Currency.ARS) && usdcBook != null) {
                    try {
                        BinanceRateService.Book arsBook = BinanceRateService.parseSpotBook(
                                RateService.fetch(BinanceRateService.SPOT_BASE + "USDCARS"), "USDCARS");
                        newUsdt.put(Currency.ARS, BinanceRateService.arsFromBooks(usdcBook, arsBook, at));
                    } catch (Exception ignored) { }
                }
                if (!newUsdt.containsKey(Currency.CNY) && newUsdt.containsKey(Currency.USD)) {
                    BigDecimal rate = newYuan != null ? newYuan.cnyPerUsd : cnyPerUsd;
                    if (rate != null) {
                        try {
                            newUsdt.put(Currency.CNY, BinanceRateService.cnyFromUsdPair(
                                    newUsdt.get(Currency.USD), rate, at));
                        } catch (Exception ignored) { }
                    }
                }
                for (Currency fiat : new Currency[]{Currency.ARS, Currency.USD, Currency.CNY}) {
                    if (!newUsdt.containsKey(fiat) && !usdtQuotes.containsKey(fiat)) {
                        if (errors.length() > 0) errors.append("；");
                        errors.append("Binance ").append(fiat.name()).append("/USDT 报价不可用");
                    }
                }
            }
            final Map<Currency, UsdtCalculator.Pair> finalUsdt = newUsdt;
            final String finalDollarRaw = dollarRaw;
            final String finalCnyRaw = cnyRaw;
            final Map<String, RateService.Quote> finalQuotes = newQuotes;
            final RateService.YuanRate finalYuan = newYuan;
            final String finalErrors = errors.toString();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                long finished = System.currentTimeMillis();
                SharedPreferences.Editor changes = prefs.edit();
                if (finalQuotes != null) {
                    quotes.clear();
                    quotes.putAll(finalQuotes);
                    fetchedDolarAt = finished;
                    changes.putString("cached_dolar", finalDollarRaw).putLong("cached_dolar_at", finished);
                }
                if (finalYuan != null) {
                    cnyPerUsd = finalYuan.cnyPerUsd;
                    cnySourceTime = finalYuan.sourceTimestampMs;
                    fetchedCnyAt = finished;
                    changes.putString("cached_cny", finalCnyRaw).putLong("cached_cny_at", finished);
                }
                for (Map.Entry<Currency, UsdtCalculator.Pair> entry : finalUsdt.entrySet()) {
                    usdtQuotes.put(entry.getKey(), entry.getValue());
                    try { changes.putString("cached_usdt_" + entry.getKey().name(),
                            BinanceRateService.pairToCache(entry.getValue())); }
                    catch (Exception ignored) { }
                }
                changes.apply();
                latestError = finalErrors;
                loading = false;
                render();
                if (manual) Toast.makeText(this, finalErrors.isEmpty() ? "汇率更新完成" : "部分更新失败，请查看缓存", Toast.LENGTH_SHORT).show();
            });
        });
    }
    @Override protected void onDestroy() {
        executor.shutdownNow();
        binanceExecutor.shutdownNow();
        super.onDestroy();
    }
}
