package com.exchange.arsusdcny;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

/** HTTP and strict JSON parsing; no fabricated fallback prices. */
public final class RateService {
    public static final String DOLAR_ENDPOINT = "https://dolarapi.com/v1/dolares";
    public static final String CNY_ENDPOINT = "https://open.er-api.com/v6/latest/USD";

    public static final String[][] MARKETS = {
            {"blue", "Blue", "市场平行汇率"},
            {"oficial", "Oficial", "银行官方汇率"},
            {"bolsa", "MEP / Bolsa", "证券市场美元"},
            {"contadoconliqui", "CCL", "海外结算美元"},
            {"cripto", "Cripto", "加密货币参考"},
            {"mayorista", "Mayorista", "银行间批发"},
            {"tarjeta", "Tarjeta", "银行卡消费参考"}
    };

    public static final class Quote {
        public final String id;
        public final String name;
        public final BigDecimal compra;
        public final BigDecimal venta;
        public final String updated;
        Quote(String id, String name, BigDecimal compra, BigDecimal venta, String updated) {
            this.id = id; this.name = name; this.compra = compra;
            this.venta = venta; this.updated = updated;
        }
    }
    public static final class YuanRate {
        public final BigDecimal cnyPerUsd;
        public final long sourceTimestampMs;
        YuanRate(BigDecimal rate, long sourceTimestampMs) {
            this.cnyPerUsd = rate; this.sourceTimestampMs = sourceTimestampMs;
        }
    }
    private RateService() {}

    public static Map<String, Quote> parseDollars(String raw) throws JSONException {
        JSONArray arr = new JSONArray(raw);
        Map<String, Quote> prices = new LinkedHashMap<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject row = arr.getJSONObject(i);
            String id = row.optString("casa", "");
            if (id.isEmpty()) continue;
            BigDecimal compra;
            BigDecimal venta;
            try {
                compra = new BigDecimal(row.get("compra").toString());
                venta = new BigDecimal(row.get("venta").toString());
            } catch (NumberFormatException | JSONException ex) {
                continue;
            }
            if (compra.signum() <= 0 || venta.signum() <= 0) continue;
            prices.put(id, new Quote(id, row.optString("nombre", id), compra, venta,
                    row.optString("fechaActualizacion", "")));
        }
        if (prices.isEmpty()) throw new JSONException("DolarAPI response contained no valid quotes");
        return prices;
    }

    public static YuanRate parseCny(String raw) throws JSONException {
        JSONObject obj = new JSONObject(raw);
        if (!"success".equals(obj.optString("result")) || !"USD".equals(obj.optString("base_code"))) {
            throw new JSONException("Unexpected USD reference exchange response");
        }
        BigDecimal cny;
        try { cny = new BigDecimal(obj.getJSONObject("rates").get("CNY").toString()); }
        catch (NumberFormatException ex) { throw new JSONException("Invalid CNY rate"); }
        if (cny.signum() <= 0) throw new JSONException("Nonpositive CNY rate");
        long stamp = obj.optLong("time_last_update_unix", 0) * 1000L;
        if (stamp <= 0) throw new JSONException("Missing USD/CNY data timestamp");
        return new YuanRate(cny, stamp);
    }

    public static String fetch(String endpoint) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(13000);
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("User-Agent", "ARS-Yuan-Converter-Android/1.0");
        try {
            int status = connection.getResponseCode();
            if (status != 200) throw new java.io.IOException("HTTP " + status);
            try (InputStream stream = connection.getInputStream();
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int length;
                while ((length = stream.read(buffer)) != -1) {
                    out.write(buffer, 0, length);
                    if (out.size() > 1024 * 1024) throw new java.io.IOException("Response too large");
                }
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } finally {
            connection.disconnect();
        }
    }
}
