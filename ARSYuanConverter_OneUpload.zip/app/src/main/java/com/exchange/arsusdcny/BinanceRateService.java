package com.exchange.arsusdcny;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import com.exchange.arsusdcny.UsdtCalculator.Pair;

/** Unauthenticated Binance public quotes. Never silently substitute a regular USD/ARS rate. */
public final class BinanceRateService {
    public static final String P2P_BASE = "https://www.binance.com/bapi/c2c/v1/public/c2c/agent/quote-price";
    public static final String SPOT_BASE = "https://data-api.binance.vision/api/v3/ticker/bookTicker?symbol=";
    public static final String P2P = "Binance P2P";
    public static final String SPOT_USDC = "Binance 现货 USDC/USDT（USD近似）";
    public static final String SPOT_ARS = "Binance 现货 USDC/ARS 交叉参考";
    public static final String CROSS_CNY = "Binance USDC/USDT × USD/CNY 交叉参考";
    private static final MathContext MC = new MathContext(18, RoundingMode.HALF_UP);
    private BinanceRateService() {}

    public static final class Book {
        public final BigDecimal bid;
        public final BigDecimal ask;
        Book(BigDecimal bid, BigDecimal ask) { this.bid = bid; this.ask = ask; }
    }

    public static String p2pUrl(String fiat, String tradeType) {
        if (!("ARS".equals(fiat) || "CNY".equals(fiat))) throw new IllegalArgumentException("Invalid fiat");
        if (!("BUY".equals(tradeType) || "SELL".equals(tradeType))) throw new IllegalArgumentException("Invalid side");
        return P2P_BASE + "?fiat=" + fiat + "&asset=USDT&tradeType=" + tradeType;
    }

    /** Public endpoint shape can evolve; only accept an explicitly labelled quote field. */
    public static BigDecimal parseP2pPrice(String raw) throws JSONException {
        JSONObject response = new JSONObject(raw);
        if (response.has("success") && !response.optBoolean("success", true))
            throw new JSONException("Binance returned unsuccessful response");
        if (response.has("code") && !"000000".equals(response.optString("code")) &&
                !"0".equals(response.optString("code")))
            throw new JSONException("Binance quote error " + response.optString("code"));
        BigDecimal price = nestedPrice(response, 0);
        if (price == null) throw new JSONException("Binance P2P quote missing/changed");
        return price;
    }
    private static BigDecimal nestedPrice(Object obj, int depth) {
        if (depth > 5 || obj == null || obj == JSONObject.NULL) return null;
        if (obj instanceof JSONArray) {
            JSONArray a = (JSONArray) obj;
            for (int i = 0; i < Math.min(4, a.length()); i++) {
                BigDecimal q = nestedPrice(a.opt(i), depth + 1);
                if (q != null) return q;
            }
        } else if (obj instanceof JSONObject) {
            JSONObject j = (JSONObject) obj;
            for (String key : new String[]{"price", "quotePrice", "unitPrice", "bestPrice", "referencePrice"}) {
                Object value = j.opt(key);
                if (value instanceof String || value instanceof Number) {
                    try {
                        BigDecimal decimal = new BigDecimal(value.toString());
                        if (decimal.signum() > 0) return decimal;
                    } catch (NumberFormatException ignored) { }
                }
            }
            for (String key : new String[]{"data", "result", "quote", "quotes", "items", "list", "adv", "priceInfo"}) {
                BigDecimal q = nestedPrice(j.opt(key), depth + 1);
                if (q != null) return q;
            }
        }
        return null;
    }

    public static Book parseSpotBook(String raw, String expectedSymbol) throws JSONException {
        JSONObject data = new JSONObject(raw);
        if (!expectedSymbol.equals(data.optString("symbol"))) throw new JSONException("Wrong Binance symbol");
        try {
            BigDecimal bid = new BigDecimal(data.getString("bidPrice"));
            BigDecimal ask = new BigDecimal(data.getString("askPrice"));
            if (bid.signum() <= 0 || ask.signum() <= 0 || bid.compareTo(ask) > 0)
                throw new JSONException("Invalid Binance spot spread");
            return new Book(bid, ask);
        } catch (NumberFormatException ex) { throw new JSONException("Invalid Binance book price"); }
    }

    /** USDC/USDT is a proxy for USD, not a promise of fiat-dollar redemption parity. */
    public static Pair usdFromUsdcBook(Book usdcUsdt, long at) {
        return new Pair(BigDecimal.ONE.divide(usdcUsdt.bid, MC),
                BigDecimal.ONE.divide(usdcUsdt.ask, MC), SPOT_USDC, at);
    }
    /** USDT->USDC (buy at ask) -> ARS (sell at bid), or reverse. */
    public static Pair arsFromBooks(Book usdcUsdt, Book usdcArs, long at) {
        return new Pair(usdcArs.ask.divide(usdcUsdt.bid, MC),
                usdcArs.bid.divide(usdcUsdt.ask, MC), SPOT_ARS, at);
    }
    public static Pair cnyFromUsdPair(Pair usdQuote, BigDecimal cnyPerUsd, long at) {
        if (cnyPerUsd == null || cnyPerUsd.signum() <= 0) throw new IllegalArgumentException("Missing USD/CNY");
        return new Pair(usdQuote.buyUsdt.multiply(cnyPerUsd, MC),
                usdQuote.sellUsdt.multiply(cnyPerUsd, MC), CROSS_CNY, at);
    }
    public static Pair fetchP2pPair(String fiat, long at) throws Exception {
        BigDecimal buy = parseP2pPrice(RateService.fetch(p2pUrl(fiat, "BUY")));
        BigDecimal sell = parseP2pPrice(RateService.fetch(p2pUrl(fiat, "SELL")));
        return p2pPair(buy, sell, at);
    }
    public static Pair p2pPair(BigDecimal buy, BigDecimal sell, long at) {
        return new Pair(buy, sell, P2P, at);
    }
    public static String pairToCache(Pair p) throws JSONException {
        return new JSONObject().put("buy", p.buyUsdt.toPlainString())
                .put("sell", p.sellUsdt.toPlainString()).put("source", p.source)
                .put("at", p.fetchedAt).toString();
    }
    public static Pair pairFromCache(String json) throws JSONException {
        JSONObject p = new JSONObject(json);
        try {
            return new Pair(new BigDecimal(p.getString("buy")), new BigDecimal(p.getString("sell")),
                    p.getString("source"), p.getLong("at"));
        } catch (IllegalArgumentException ex) {
            throw new JSONException("Invalid cached Binance quote");
        }
    }
}
