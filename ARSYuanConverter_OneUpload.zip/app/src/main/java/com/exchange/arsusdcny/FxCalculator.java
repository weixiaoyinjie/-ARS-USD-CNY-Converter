package com.exchange.arsusdcny;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/** Deterministic cross-currency math. No network calls or UI dependencies. */
public final class FxCalculator {
    public enum Currency { ARS, USD, CNY, USDT }
    public static final MathContext MC = new MathContext(18, RoundingMode.HALF_UP);

    private FxCalculator() {}

    /**
     * compra = ARS paid by the desk for one USD (customer sells USD).
     * venta  = ARS charged by the desk for one USD (customer buys USD).
     * cnyPerUsd = indicative CNY for one USD, not a CNY cash buy/sell rate.
     */
    public static BigDecimal convert(BigDecimal amount, Currency from, Currency to,
                                     BigDecimal compra, BigDecimal venta, BigDecimal cnyPerUsd) {
        if (amount == null || from == null || to == null) throw new IllegalArgumentException("Missing amount/currency");
        if (amount.signum() < 0) throw new IllegalArgumentException("Negative amount");
        if (from == to) return amount;
        if (from == Currency.USDT || to == Currency.USDT)
            throw new IllegalArgumentException("Use UsdtCalculator for direct Binance USDT quotes");
        if (compra == null || venta == null || cnyPerUsd == null ||
            compra.signum() <= 0 || venta.signum() <= 0 || cnyPerUsd.signum() <= 0) {
            throw new IllegalArgumentException("Missing or invalid exchange rate");
        }
        BigDecimal usd;
        switch (from) {
            case ARS:
                usd = amount.divide(venta, MC);
                break;
            case CNY:
                usd = amount.divide(cnyPerUsd, MC);
                break;
            default:
                usd = amount;
        }
        switch (to) {
            case ARS:
                return usd.multiply(compra, MC);
            case CNY:
                return usd.multiply(cnyPerUsd, MC);
            default:
                return usd;
        }
    }

    /** Accept plain numbers, Chinese/RMB currency signs, comma grouping and decimal-comma input. */
    public static BigDecimal parseAmount(String original) {
        if (original == null) throw new NumberFormatException("请输入金额");
        String s = original.trim().replace(" ", "").replace("\u00a0", "")
                .replace("¥", "").replace("￥", "").replace("$", "")
                .replace("₱", "").replace("ARS", "").replace("USDT", "").replace("USD", "").replace("CNY", "");
        if (s.isEmpty()) throw new NumberFormatException("请输入金额");
        int dot = s.lastIndexOf('.');
        int comma = s.lastIndexOf(',');
        if (dot >= 0 && comma >= 0) {
            if (dot > comma) s = s.replace(",", "");
            else s = s.replace(".", "").replace(',', '.');
        } else if (comma >= 0) {
            if (s.matches("\\d{1,3}(,\\d{3})+")) s = s.replace(",", "");
            else if (s.matches("\\d+,\\d{1,6}")) s = s.replace(',', '.');
            else throw new NumberFormatException("金额格式不正确");
        } else if (dot >= 0) {
            if (s.matches("\\d{1,3}(\\.\\d{3}){2,}")) s = s.replace(".", "");
            else if (s.matches("\\d{1,3}\\.\\d{3}") && !s.startsWith("0.")) s = s.replace(".", "");
        }
        if (!s.matches("\\d+(\\.\\d+)?")) throw new NumberFormatException("金额格式不正确");
        BigDecimal value = new BigDecimal(s);
        if (value.compareTo(new BigDecimal("1000000000000000")) > 0) throw new NumberFormatException("金额超出范围");
        return value;
    }
}
